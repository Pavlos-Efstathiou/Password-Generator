## How could I use this library?
#### The best way to use it, in my opinion is to install it with pip
#### Just type ```pip3 install passgenpy``` on your Linux or WSL terminal (on Windows just remove the 3 from pip)
#### Or alternatively you could clone this and use ```passgenpy/generate_password.py``` in place of the module.
#### If you had used pip to download the library do ```from passgenpy.generate_password import gen_pass``` to just import the function to generate the password, and to import the whole library ```import passgenpy```.

## Will you add new features to this library?
#### When I have free time I will work on this library and add even more features!

## Can I contribute to this project
#### Of course, anyone can!

## What should I do if I find any bugs or issues with your code
#### To report an issue or bug go to the issues tab and create a new issue. It's that simple!


